# Event Creation API Documentation

This API manages event creation in a Laravel application with Supabase.

## Resources
- [Create Event](events.md)

## Setup
- Base URL: `http://localhost:8000/events`
- Use Thunder Client or Postman to test.
- Import `create-event-collection.json` from `api-docs` to test the endpoint.
