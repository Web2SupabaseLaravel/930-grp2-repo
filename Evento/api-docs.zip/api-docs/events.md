# Create Event API Documentation

This document describes the API endpoint for creating an event in the Laravel application.

## Base URL
`http://localhost:8000/events`

---

## Create an Event
Create a new event (used in the Create Event page).

### Endpoint
**POST** `/events`

### Headers
- `Content-Type: application/json`

### Request Body
```json

Response
Status Code: 201 Created
{
    "event_name": "Music Festival",
    "address": "123 Main St, City",
    "description": "A fun music festival with live bands.",
    "photo": "https://example.com/photo.jpg",
    "price": 50,
    "number_of_ticket": 100,
    "date": "2025-06-01",
    "category_id": 1,
}

Error Responses
Status Code: 422 Unprocessable Entity
{
    "message": "The given data was invalid.",
    "errors": {
        "event_name": ["The event name field is required."],
        "date": ["The date must be a date after or equal to today."],
        "category_id": ["The category id must exist in categories."],
        "user_id": ["The user id must exist in users."]
    }
}
